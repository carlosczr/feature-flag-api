﻿using HobknobClientNet;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Unity;

namespace HobknobClientNetDemo.Controllers
{
    public class TogglesController : ApiController
    {
        private IHobknobClient hobknobClient;

        public TogglesController(IHobknobClient hobknobClient)
        {
            
            this.hobknobClient = hobknobClient;
        }


        // GET api/toggles
        [Route("api/toggles")]
        public Dictionary<string, bool> Get() => hobknobClient.GetAll();

        // GET api/toggles/feature
        [Route("api/toggles/{feature}")]
        public Tuple<string, bool> Get(string feature) => new Tuple<string, bool>(feature, hobknobClient.GetOrDefault(feature, false));

        // GET api/toggles/feature/toggle
        [Route("api/toggles/{feature}/{toggle}")]
        public Tuple<string, bool> Get(string feature, string toggle) => new Tuple<string, bool>($"{feature}/{toggle}", hobknobClient.GetOrDefault(feature, toggle, false));
    }
}
