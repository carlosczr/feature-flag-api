﻿using HobknobClientNet;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HobknobClientNetDemo.Controllers
{
    public class HomeController : Controller
    {
        private IHobknobClient hobknobClient;

        public HomeController(IHobknobClient hobknobClient)
        {
            this.hobknobClient = hobknobClient;
        }

        public ActionResult Index()
        {
            ViewBag.Title = "Home Page";
            ViewBag.HobknobUrl = ConfigurationManager.AppSettings["HobknobUrl"];
            ViewBag.EtcdBrowser = ConfigurationManager.AppSettings["EtcdBrowser"];
            ViewBag.LTR = hobknobClient.GetOrDefault("LTR", true);

            return View();
        }
    }
}
